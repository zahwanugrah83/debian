#!/bin/bash

#echo 1 > /proc/sys/vm/drop_caches
#sleep 3

echo 3 > /proc/sys/vm/drop_caches
